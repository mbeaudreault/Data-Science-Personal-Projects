def main():
    listeningData = open("listeningData.txt", "r")
    readData(listeningData)
    listeningData.close()

    
def readData(listeningData):
    line = listeningData.readline()
    cnt = 1
    while line:
        line = listeningData.readline()
        cnt += 1
        #gets artist name
        if '              "name":' in line:
            line = line.replace('              "name": "', "")
            line = line.replace('",', "")
            line.rstrip()
            print("artist name: " + str(line))
        #get album name
        elif '          "type": "album",' in line:
            previousLine = previousLine.replace('          "name": "', "")
            previousLine = previousLine.replace('",', "")
            print("Album Name: " + str(previousLine))
        #get song name
        elif '       "popularity":' in line:
            previousLine = previousLine.replace('        "name": "', "")
            previousLine = previousLine.replace('",', "")
            line = line.replace('        "popularity": ', "")
            line = line.replace(',', "")
            print("Song Name: " + str(previousLine))
            print("popularity: " + str(line))
        elif '        "duration_ms":' in line:
            line = line.replace('        "duration_ms": ', "")
            line = line.replace(',', "")
            durationInSeconds = (int(line))/1000
            print("Duration: " + str(durationInSeconds))
        previousLine = line
    return 1
