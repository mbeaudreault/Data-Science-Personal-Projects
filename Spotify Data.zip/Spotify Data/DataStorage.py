def main():
    listeningData = open("listeningData.txt", "r")
    readData(listeningData)
    listeningData.close()

    
def readData(listeningData):
    import csv
    with open('listeningDataTable.csv', 'w') as csvfile:
        fieldnames = ['Artist_Name', 'Album_Name', 'Duration', 'Song_Name', 'Populatiry', 'Played_At']
        writer = csv.DictWriter(csvfile,fieldnames=fieldnames)
        writer.writeheader()
        done = False
        
        line = listeningData.readline()
        cnt = 1
        while line:
            line = listeningData.readline()
            cnt += 1
            #gets artist name
            if '              "name":' in line:
                line = line.replace('              "name": "', "")
                line = line.replace('",', "")
                artistName = line.rstrip()
            #get album name
            elif '          "type": "album",' in line:
                previousLine = previousLine.replace('          "name": "', "")
                previousLine = previousLine.replace('",', "")
                albumName = previousLine.rstrip()
            #get song name
            elif '       "popularity":' in line:
                previousLine = previousLine.replace('        "name": "', "")
                previousLine = previousLine.replace('",', "")
                line = line.replace('        "popularity": ', "")
                line = line.replace(',', "")
                songName = previousLine.rstrip()
                popularity = line.rstrip()
            elif '        "duration_ms":' in line:
                line = line.replace('        "duration_ms": ', "")
                line = line.replace(',', "")
                durationInSeconds = (int(line))/1000
                duration=  str(durationInSeconds)
            elif '      "played_at": "' in line:
                line = line.replace('      "played_at": "', "")
                line = line .replace('",', "")
                playedAt = line.rstrip()
                done = True
            if(done == True):
                writer.writerow({'Artist_Name': artistName, 'Album_Name': albumName, 'Duration': duration, 'Song_Name': songName, 'Populatiry': popularity, 'Played_At': playedAt})
                done = False
            previousLine = line
    return 1
