/*****************************************************************************
 Excerpt from "Linux Programmer's Guide - Chapter 6"
 (C)opyright 1994-1995, Scott Burkett
 ***************************************************************************** 
 MODULE: fifoclient.c
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>

//	client pipeName message
//#define FIFO_FILE       "MYFIFO"

int main(int argc, char *argv[])
{
        FILE *fp;

        if ( argc != 3 ) {
                printf("USAGE: fifo_client [string] [string]\n");
                exit(1);
        }

        if((fp = fopen(argv[1], "w")) == NULL) {
                perror("fopen");
                exit(1);
        }

        fputs(argv[2], fp);

        fclose(fp);
        return(0);
}
