//
//  main_unnamed.c
//  Unnamed Pipes Example
//
//  Code adapted from "Interprocess Communications in Unix - The Nooks & Crannies"
//						John Shapley Gray. Prentice Hall PTR, 1998.
//

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define READ_END   0
#define WRITE_END  1

int main(int argc, const char * argv[])
{
	
	if (argc !=2) {
		fprintf(stderr, "Usage: %s message\n", *argv);
		exit(1);
	}
	
	static char message[BUFSIZ];
	
	//	Create the pipe to send data from the parent process to the child process.
	//	After the fork, the pipe will be accessible by both the parent process and
	//	the child process.  The parent will be writing on the WRITE_END while the child
	//	will be reading on the READ_END.
	int file_desc_PtoC[2];
	int file_desc_CtoP[2];
	
	if (pipe(file_desc_PtoC) == -1) {
		perror("Pipe P to C");
		exit(2);
	}
	if (pipe(file_desc_CtoP) == -1) {
		perror("Pipe C to P");
		exit(2);
	}

	int p = fork();
	switch (p) {
		// problem
		case -1:
			perror("Fork failed");
			exit(3);
			break;
		
		// in the child
		case 0:

			//	not required but general good practice
			close(file_desc_PtoC[WRITE_END]);
			close(file_desc_CtoP[READ_END]);

			if (read(file_desc_PtoC[READ_END], message, BUFSIZ) != -1) {
				printf("Message received by child: [%s]\n", message);
				fflush(stdout);
			}
			else {
				perror(" Child Read failed");
				exit(4);
			}
			
			strcat(message, " --> sent back");
			
			if (write(file_desc_CtoP[WRITE_END], message, strlen(message)) != -1) {
				printf("Message sent back by child: [%s]\n", message);
				fflush(stdout);
			}
			else {
				perror("Child Write back failed");
				exit(5);
			}

			break;
		
		//	in the parent
		default:

			//	not required but general good practice
			close(file_desc_PtoC[READ_END]);
			close(file_desc_CtoP[WRITE_END]);
			
			if (write(file_desc_PtoC[WRITE_END], argv[1], strlen(argv[1])) != -1) {
				printf("Message sent by parent: [%s]\n", argv[1]);
				fflush(stdout);
			}
			else {
				perror("Parent Write failed");
				exit(5);
			}
			
			usleep(1000000);
			
			if (read(file_desc_CtoP[READ_END], message, BUFSIZ) != -1) {
				printf("Message received by parent: [%s]\n", message);
				fflush(stdout);
			}
			else {
				perror(" Parent Read failed");
				exit(4);
			}			
			
			break;
	}
	
    return 0;
}
