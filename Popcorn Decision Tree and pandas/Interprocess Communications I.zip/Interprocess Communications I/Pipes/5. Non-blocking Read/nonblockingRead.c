//=========================================================================
//	This code comes from the page "Non-blocking I/O with pipes in C"
//	by Kadam Patel on GeeksForGeeks
//	http://www.geeksforgeeks.org/non-blocking-io-with-pipes-in-c/
//
//	In this program, the parent process is going to operate as a server
//	that gets messages from the child process, which operates as a client.
//	The server checks every second for new messages, but the client only
//	send a message every 3 seconds.  In the default behavior of a pipeline,
//	the server would remain blocked for 2s until the client's message
//	arrives.  In this non-blocking setup, the server actually gets to check
//	the pipeline 3 times per second and get some work done (well, here, it
//	only sleeps) between checks.
//	-----------------------------------------------------------------------
//	Only minor editing done to fix errors and warnings in -Wall mode
//	Being a complete egomaniac, I prefixed all my changes with a
//	comment line //jyh 2017-2018
//
//	jyh 2017-10-13, rev. 2018-03-03
//=========================================================================

// C program to illustrate
// non I/O blocking calls
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h> 	// library for fcntl function

#define READ_END   0
#define WRITE_END  1

//jyh 2017-2018
#include <stdlib.h>	//	for exit system call
#include <errno.h>	//	defines some error handling constants and errno global
void parent_read(int p[]);
void child_write(int p[]);


//jyh 2017-2018
//	Don't forget the terminating 0 when you calculate the size of
//	your C-string-storing arrays.
#define MESSAGE_SIZE 6
char msg1[MESSAGE_SIZE] = "hello";
char msg2[MESSAGE_SIZE] = "bye!!";

//jyh 2017-2018
//int main()
int main(int argc, char* argv[])
{
	//	This variable will store the file descriptors for
	//	the two ends of the pipe
    int p[2];
	
    // error checking for pipe creation
    if (pipe(p) < 0)
        exit(1);
	
    // Remember the fcntl function we used in one version of file
    //	locking?  As explained in the notes, this is a very general
    //	function for changing file settings (in many ways, it is so
    //	general that it's almost non-Unix-like, except for the
    //	stupid abbreviated identifier.
    if (fcntl(p[READ_END], F_SETFL, O_NONBLOCK) < 0)
        exit(2);
	
    // If we reach this point, it means that the reading end of the
    //	pipe was properly set to handle non-blocking reading calls.
    switch (fork()) {
 
		// error
		case -1:
			exit(3);
 
		// 0 for child process
		case 0:
			child_write(p);
			break;
 
		default:
			parent_read(p);
			break;
    }

    return 0;
}

void parent_read(int p[])
{
	//jyh 2017-2018
    //int nread;
    long nread;
    char buf[MESSAGE_SIZE];
	
    // As usual, this is not required, just cleaner.
    close(p[WRITE_END]);
	
    while (1) {
 
        // read call if return -1 then pipe is
        // empty because of fcntl
        nread = read(p[READ_END], buf, MESSAGE_SIZE);
        switch (nread) {
        case -1:
 
            // case -1 means pipe is empty and errno
            // set EAGAIN
            if (errno == EAGAIN) {
                printf("(pipe empty)\n");
                sleep(1);
                break;
            }
			//jyh 2017-2018
			//	This should not be happening.  If the read fails for a reason
			//	other than pipe empty, then something went wrong with the pipe.
			//	Here, we simply abort.
            else {
                perror("read");
                exit(4);
            }
 
        // case 0 means all bytes are read and EOF (end of conversation)
        case 0:
            printf("End of conversation\n");
 
            // read link
            close(p[READ_END]);
 
            exit(0);

        default:
 
            // text read
            // by default return number of bytes
            // that read call managed to at that time
            printf("MSG = %s\n", buf);
        }
    }
}


void child_write(int p[])
{
    int i;
	
    // As usual, this is not required, just cleaner.
    close(p[READ_END]);
	
    // write 3 times "hello" in 3 second interval
    for (i = 0; i < 3; i++) {
        write(p[WRITE_END], msg1, MESSAGE_SIZE);
        sleep(3);
    }
	
    // write "bye" one time
    write(p[WRITE_END], msg2, MESSAGE_SIZE);
	
	// The original comment below...
	//
    // here after write all bytes then write end
    // doesn't close so read end block but
    // because of fcntl block doesn't happen.
    exit(3);
//	while(1);
	
}
