/*****************************************************************************
 Excerpt from "Linux Programmer's Guide - Chapter 6"
 (C)opyright 1994-1995, Scott Burkett
 ***************************************************************************** 
 MODULE: fifoclient.c
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define FIFO_FILE_CtoS       "MYFIFO_1"
#define FIFO_FILE_StoC       "MYFIFO_2"

int main(int argc, char *argv[])
{
	FILE *fp;
	FILE *fp2;

	if ( argc != 2 ) {
			printf("USAGE: fifo_client [string]\n");
			exit(1);
	}

	if((fp = fopen(FIFO_FILE_CtoS, "w")) == NULL) {
			perror("fopen");
			exit(1);
	}

	fputs(argv[1], fp);
	fclose(fp);

	usleep(1000000);
	
	char readbuf[80];
	fp2 = fopen(FIFO_FILE_StoC, "r");
	fgets(readbuf, 80, fp2);
	fclose(fp2);
	printf("Client received back string: %s\n", readbuf);                

	return(0);
}
