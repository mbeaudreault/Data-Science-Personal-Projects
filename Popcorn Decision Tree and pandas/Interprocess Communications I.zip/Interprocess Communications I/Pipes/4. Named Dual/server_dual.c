/*****************************************************************************
 Excerpt from "Linux Programmer's Guide - Chapter 6"
 (C)opyright 1994-1995, Scott Burkett
 ***************************************************************************** 
 MODULE: fifoserver.c
 *****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>


//#include <linux/stat.h>

#define FIFO_FILE_CtoS       "MYFIFO_1"
#define FIFO_FILE_StoC       "MYFIFO_2"

int main(void)
{
	FILE *fp;
	FILE *fp2;
	char readbuf[80];

	/* Create the FIFO if it does not exist */
	umask(0);
	mknod(FIFO_FILE_CtoS, S_IFIFO|0666, 0);
	mknod(FIFO_FILE_StoC, S_IFIFO|0666, 0);

	while(1)
	{
			fp = fopen(FIFO_FILE_CtoS, "r");
			fgets(readbuf, 80, fp);
			printf("Received string: %s\n", readbuf);                
			fclose(fp);
			
			char outbuf[120];
			strcpy(outbuf, "string received: ");
			strcat(outbuf, readbuf);

			if((fp2 = fopen(FIFO_FILE_StoC, "w")) == NULL) {
				perror("fopen");
				exit(1);
			}

			fputs(outbuf, fp2);
			fclose(fp2);

	}

	return(0);
}


